=== Discount based on Number of Order For WooCommerce ===
Contributors: extensionhawk,varun
Requires at least: 3.0.1
Tested up to: 4.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
This plugin allows you to provide discount based on users email id in a simple and easy way

== Description ==
This plugin allows you to provide discount based on users email id in a simple and easy way

== Installation ==
 
This section describes how to install the plugin and get it working.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
 
== Frequently Asked Questions ==
 

== Screenshots ==

 
== Changelog ==
 
= 1.0 =
* First Version
