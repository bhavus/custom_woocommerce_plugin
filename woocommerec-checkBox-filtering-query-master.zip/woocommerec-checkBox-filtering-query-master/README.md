# woocommerec-checkBox-filtering-query

## Synopsis
Use this action to change shop page query

Usage
-----
Apply the action in your function file.

```ruby
 add_action('woocommerce_product_query', 'filter_shoop_posts_query');
```
