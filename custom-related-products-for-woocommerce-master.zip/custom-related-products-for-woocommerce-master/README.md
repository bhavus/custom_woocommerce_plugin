Custom Related Products for WooCommerce
=======================================

Custom Related Products for WooCommerce lets you choose which products should show in the related products area on a product detail page instead of simply showing products from the same category. This plugin has been tested with WooCommerce from version 2.1 to 3.0.

The `master` branch of this repository is intended to reflect the stable and current version of the plugin, however it is recommended that you install the plugin from your dashboard or from [the WordPress plugin directory](https://wordpress.org/plugins/custom-related-products-for-woocommerce/) to ensure you always have the official release.

